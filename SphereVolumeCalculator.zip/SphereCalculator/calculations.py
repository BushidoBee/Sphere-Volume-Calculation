import math

def volumecalc(radius):
    product = (4/3) * math.pi * math.pow(radius, 3)
    return product