class RadiusError(Exception):
    pass